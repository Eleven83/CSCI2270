#include <iostream>

using namespace std;

struct Node
{
	int id;
	Node *next;
};

void dispSLL(Node *head);

int main()
{
	Node* head, *current, *tmp;
	head = new Node;
	current = new Node;

	// build LL and fill with some values
	int arr[]={9,2,4,5,1,2,4};
	int arrL=7;
	head->id=arr[0];
	head->next = nullptr;
	current=head;
	int i=1;
// *****************************************
// STUDENT CODE HERE
	while(i<arrL)
	{
		tmp=new Node;
		tmp->id=arr[i];
		tmp->next=nullptr;
		current->next=tmp;
		current=tmp;
		i++;
	}
	//Display the LL
	dispSLL(head);

// STUDENT CODE END
// *****************************************
	return 0;
}

void dispSLL(Node *head)
{
	Node *current = head;
	while(current!=nullptr)
	{
		cout<<current->id<<" ";
		current=current->next;
	}
	cout<<"\n\n";
}

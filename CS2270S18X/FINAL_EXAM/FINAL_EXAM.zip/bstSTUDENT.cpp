#include <iostream>

using namespace std;


struct TreeNode
{
    int key;
    TreeNode *left;
    TreeNode *right;
    TreeNode *parent;
};

TreeNode* addNode(TreeNode *root, int value);

void func(TreeNode *root);
void func(TreeNode *root);

int main()
{
    TreeNode *root = NULL;

    // int a[] = {7,9,5,3};
    // int alength = 4;
    int a[] = {5,97,57,33};
    int alength = 4;

    for(int i=0; i<alength; i++)
    {
        root=addNode(root, a[i]);
    }
    func(root);
    return 0;
}

TreeNode* addNode(TreeNode *root, int value)
{
    TreeNode *newnode = new TreeNode;
    newnode->key=value;
    newnode->left=NULL;
    newnode->right=NULL;
    newnode->parent=NULL;
    if(root == NULL)
    {
        root=newnode;
    }
    else
    {
        TreeNode *temp = root;
        TreeNode *temp2 = NULL;
        while(temp!=NULL)
        {
            temp2=temp;
            if(temp->key > value)
            {
                temp = temp->left;
            }
            else
            {
                temp = temp->right;
            }
        }
        if(value<temp2->key)
        {
            newnode->parent = temp2;
            temp2->left = newnode;
        }
        else
        {
            newnode->parent = temp2;
            temp2->right = newnode;
        }

    }
    return root;
}

void func(TreeNode *root)
{
// STUDENT CODE: complete this function
    if(root)
    {
        func(root->left);
        if(root->left==NULL && root->right==NULL)
            root->key-=1;
        cout<<root->key<<" ";
        func(root->right);
    }
}

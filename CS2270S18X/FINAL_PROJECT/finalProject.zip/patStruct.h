#ifndef patStruct_H
#define patStruct_H
#include <iostream>

using namespace std;

struct Patient
{
    string name;
    int priority;
    int treatment;
};

#endif
